AXOLOTL WEBSITE — SITE-READY PACKAGE

This folder contains:
- index.html (the redesigned website)
- images/ (your nine original product photos, unchanged)

IMPORTANT: Keep index.html and the images folder together in the same location.

PUBLISH ON GITHUB PAGES FROM IPHONE
1. Open your GitHub repository in Safari and sign in.
2. Open the repository's main Code page.
3. Tap Add file > Upload files.
4. Upload index.html AND the entire images folder with all nine photos. If GitHub mobile does not let you upload a folder, open images on your phone/computer and upload all nine files into a repository folder named exactly: images
5. Commit the changes to the main branch.
6. Open Settings > Pages. Choose Deploy from a branch, branch main, folder /(root), and Save.
7. Wait a minute or two, then open the Pages URL shown by GitHub.

Do not upload only index.html: the product photos need the images folder.
WhatsApp ordering links use +234 916 385 2657. TikTok: @axolotl.beyond.
No prices are shown because confirmed retail prices were not supplied.
